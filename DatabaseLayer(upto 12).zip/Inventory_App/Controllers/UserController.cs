﻿using DatabaseLayer;
using Inventory_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inventory_App.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        private InventoryERPDbEntities DB = new InventoryERPDbEntities();
        public ActionResult AllUserTypes()
        {
            if (string.IsNullOrEmpty(Convert.ToString(Session["UserName"])))
            {
                return RedirectToAction("Login", "Home");
            }
            var userid = 0;
            var usertypeid = 0;
            int.TryParse(Convert.ToString(Session["UserID"]), out userid);
            int.TryParse(Convert.ToString(Session["UserTypeID"]), out usertypeid);
            if (usertypeid != 1)
            {
                return RedirectToAction("Admin", "Dashboard");
            }

            var list = new List<UserTypeMV>();
            var usertypes = DB.tblUserTypes.ToList();
            foreach ( var userType in usertypes ) 
            { 
                list.Add(new UserTypeMV() { UserTypeID = userType.UserTypeID, UserType = userType.UserType });
            }

            return View(list);
        }
    }
}